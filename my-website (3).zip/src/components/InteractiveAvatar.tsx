import React, { useState, useEffect, useRef } from 'react';

interface InteractiveAvatarProps {
  imageSrc?: string;
  size?: number; // Default 120px
  maxOffset?: number; // Default 14px
}

/**
 * Interactive Floating Avatar Component
 * 
 * - Fixed 120x120px circular container positioned at bottom: 30px, right: 30px (z-index: 9999)
 * - Detects mouse cursor coordinates across the entire document
 * - Calculates gaze vector from avatar center to cursor
 * - Translates the internal <img> tag smoothly (10-15px max) to create gaze tracking
 */
export const InteractiveAvatar: React.FC<InteractiveAvatarProps> = ({
  imageSrc = 'max-avatar-clean.png',
  size = 120,
  maxOffset = 14,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    const container = containerRef.current;
    const img = imgRef.current;
    if (!container || !img) return;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;

      // Distance vector from avatar center to cursor
      const deltaX = e.clientX - centerX;
      const deltaY = e.clientY - centerY;

      // Normalize by viewport radius
      const maxRadiusX = Math.max(centerX, window.innerWidth - centerX) || window.innerWidth / 2;
      const maxRadiusY = Math.max(centerY, window.innerHeight - centerY) || window.innerHeight / 2;

      const normX = deltaX / maxRadiusX;
      const normY = deltaY / maxRadiusY;

      // Parallax gaze calculation: cursor top-left -> image translates slightly bottom-right
      const targetX = Math.max(-maxOffset, Math.min(maxOffset, -normX * maxOffset));
      const targetY = Math.max(-maxOffset, Math.min(maxOffset, -normY * maxOffset));

      img.style.transform = `translate(${targetX.toFixed(2)}px, ${targetY.toFixed(2)}px)`;
    };

    const handleMouseLeave = () => {
      img.style.transform = 'translate(0px, 0px)';
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches && e.touches.length > 0) {
        const touch = e.touches[0];
        handleMouseMove({ clientX: touch.clientX, clientY: touch.clientY } as MouseEvent);
      }
    };

    const handleTouchEnd = () => {
      handleMouseLeave();
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    window.addEventListener('mouseleave', handleMouseLeave);
    window.addEventListener('touchmove', handleTouchMove, { passive: true });
    window.addEventListener('touchend', handleTouchEnd);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseleave', handleMouseLeave);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
    };
  }, [maxOffset]);

  return (
    <aside
      aria-label="دستیار آواتار تعاملی"
      className="fixed z-[9999] pointer-events-auto"
      style={{
        bottom: '30px',
        right: '30px',
      }}
    >
      {/* 
        1. Fixed Circular Avatar Container (120x120px, border-radius: 50%, overflow: hidden)
      */}
      <div
        ref={containerRef}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        className="relative w-[96px] h-[96px] sm:w-[120px] sm:h-[120px] rounded-full overflow-hidden cursor-pointer select-none"
        style={{
          border: '3.5px solid rgba(255, 255, 255, 0.85)',
          boxShadow: isHovered
            ? '0 18px 36px rgba(0, 0, 0, 0.5), 0 0 35px rgba(56, 189, 248, 0.6), inset 0 0 15px rgba(0, 0, 0, 0.2)'
            : '0 12px 30px rgba(0, 0, 0, 0.45), 0 0 25px rgba(56, 189, 248, 0.35), inset 0 0 15px rgba(0, 0, 0, 0.2)',
          transform: isHovered ? 'scale(1.05)' : 'scale(1)',
          transition: 'transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.25s ease',
          background: 'linear-gradient(135deg, #6366f1 0%, #3b82f6 100%)',
        }}
      >
        {/* 
          2. Scaled Avatar Image with Gaze Tracking Transform
        */}
        <img
          ref={imgRef}
          src={imageSrc}
          alt="Interactive 3D Avatar"
          className="block w-[125%] h-[125%] max-w-none object-cover object-[50%_12%] pointer-events-none"
          style={{
            marginLeft: '-12.5%',
            marginTop: '-12.5%',
            transition: 'transform 0.1s ease-out',
            willChange: 'transform',
          }}
          onError={(e) => {
            // Fallback gracefully if primary asset name changes
            const target = e.currentTarget;
            if (!target.src.includes('profile-photo-web.jpg')) {
              target.src = '/profile-photo-web.jpg';
            }
          }}
        />
      </div>

      {/* 
        3. Online Status Indicator Badge
      */}
      <span
        aria-hidden="true"
        className="absolute bottom-1 right-1 w-4 h-4 sm:w-5 sm:h-5 bg-emerald-500 border-2 sm:border-[2.5px] border-white rounded-full shadow-md pointer-events-none"
      />
    </aside>
  );
};
